package com.example.cajero_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
