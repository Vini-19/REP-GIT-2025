package com.example.entero

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
