package com.example.aritmetica_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
