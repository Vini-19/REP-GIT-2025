package com.example.farmacia_descuento

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
